package midend.generation.Items.LLvmIRSpecificType;

import midend.generation.Items.LLvmIRType;

public class StructType extends LLvmIRType {
    private final String name;

    public StructType(String name) {
        this.name = name;
    }
}
