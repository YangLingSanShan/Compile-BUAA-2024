package midend.optimizer;

public class LoopVal {
}
