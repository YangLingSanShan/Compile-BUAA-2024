package backend.AssembleCodes.Codes;

import backend.AssembleCodes.Units.Assemble;

public abstract class Fake extends Assemble {
}
